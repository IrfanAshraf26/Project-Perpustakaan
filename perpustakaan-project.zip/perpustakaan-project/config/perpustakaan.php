<?php

return [
    /**
     * Lamanya peminjaman.
     */
    'borrow_days' => 3,

    /**
     * Besar denda keterlambatan per hari.
     */
    'late_price' => 500,

    /**
     * Besar denda kehilangan per buku.
     */
    'book_price' => 50000,
];